#### steps to reproduce
1.
2.
3.

#### browser version and os version and summernote version
What is your browser and OS?
What is your summernote version?

#### screenshot of issue
Add screenshot which shows your issue(if needed).
You can make [gif from Recordit](http://www.recordit.co/).

If you can make the issue using jsfiddle(https://jsfiddle.net/), We can save time to reproduce the problem.
