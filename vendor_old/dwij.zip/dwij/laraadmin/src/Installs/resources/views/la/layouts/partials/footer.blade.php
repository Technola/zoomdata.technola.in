@if(!isset($no_padding))
<footer class="main-footer">
    <div class="pull-right hidden-xs">
        Powered by <a href="http://dwijitsolutions.com">Dwij IT Solutions</a>
    </div>
    <strong>Copyright &copy; 2016
</footer>
@endif